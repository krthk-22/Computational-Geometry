rm -r 100_tests/diagonals
rm -r 100_tests/gifs