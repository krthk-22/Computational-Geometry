rm -r diagonals
rm -r gifs
rm time.txt time.png
rm triangulation_n4 triangulation_n2 triangulation_my